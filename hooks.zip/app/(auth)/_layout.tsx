import { Slot } from "expo-router";
export default function GroupLayout() {
  return <Slot />;
}
